# Practice Desk

A free question-practice website for students. Pick a subject, answer multiple-choice questions, see the right answer and an explanation straight away, and review what you missed at the end. Scores are saved in the student's own browser.

It is plain HTML, CSS and JavaScript. There is nothing to install and no server.

## Put it online with GitHub Pages

1. Create a new repository on GitHub (for example `practice-desk`) and make it **Public**.
2. Upload all the files from this folder: `index.html`, `style.css`, `app.js`, `questions.js` and `README.md`.
3. In the repository go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to **Deploy from a branch**, choose the `main` branch and the `/ (root)` folder, then **Save**.
5. After a minute or two, GitHub shows your site address, usually `https://YOUR-USERNAME.github.io/practice-desk/`. Share that link with students.

## Add or change questions

Open `questions.js` and edit it. Each question looks like this:

```js
{
  q: "What is the derivative of x³?",
  options: ["x²", "3x²", "3x³", "x³/3"],
  answer: 1,                 // position of the correct option, starting from 0
  explain: "Power rule: d/dx xⁿ = nxⁿ⁻¹."
}
```

To add a new subject, copy a whole subject block (with its `id`, `name` and `questions` list), change the `id` to something unique and the `name` to what students should see.

You can edit the file right in GitHub: open `questions.js`, click the pencil icon, change it, and choose **Commit changes**. The site updates within a minute.

## Try it on your computer

Double-click `index.html` to open it in your browser.

## Notes

- Every question needs `answer` to match a real position in `options`. If a round shows the wrong answer as correct, check that number first.
- Students' scores are stored only in their own browser, so clearing site data resets them.

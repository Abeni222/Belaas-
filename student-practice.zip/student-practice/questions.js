/*
  QUESTION BANK
  -------------
  Add or edit questions here. No other file needs to change.

  Each question:
    q        the question text
    options  2 to 6 answer choices (the site shuffles them for students)
    answer   the position of the correct option, counting from 0
    explain  a short explanation shown after the student answers

  Each subject needs a unique id (lowercase letters, no spaces) and a name.
  Copy a whole { ... } subject block to add a new subject.
*/
window.QUESTION_BANK = {
  subjects: [
    {
      id: "biology",
      name: "Biology",
      questions: [
        {
          q: "In which part of the cell do the reactions of the Krebs cycle take place?",
          options: ["Ribosome", "Mitochondrial matrix", "Golgi apparatus", "Lysosome"],
          answer: 1,
          explain: "The Krebs cycle enzymes are in the matrix of the mitochondrion, the inner fluid-filled space."
        },
        {
          q: "Two heterozygous parents (Aa × Aa) are crossed. What is the expected phenotype ratio of dominant to recessive offspring?",
          options: ["1 : 1", "3 : 1", "1 : 2 : 1", "9 : 3"],
          answer: 1,
          explain: "The genotypes are 1 AA : 2 Aa : 1 aa. AA and Aa show the dominant trait, so the phenotype ratio is 3 : 1."
        },
        {
          q: "DNA replication is called semiconservative because each new DNA molecule contains:",
          options: ["Two brand new strands", "Two old strands", "One old strand and one new strand", "Fragments of RNA only"],
          answer: 2,
          explain: "Each parent strand acts as a template, so every daughter molecule keeps one original strand and gains one new one."
        },
        {
          q: "Which enzyme builds the mRNA strand during transcription?",
          options: ["DNA ligase", "Helicase", "RNA polymerase", "Peptidyl transferase"],
          answer: 2,
          explain: "RNA polymerase reads the DNA template and joins RNA nucleotides into mRNA."
        },
        {
          q: "Which blood group can donate red blood cells to every other ABO and Rh group?",
          options: ["AB positive", "O negative", "A negative", "B positive"],
          answer: 1,
          explain: "O negative red cells carry no A, B or Rh antigens, so recipients' antibodies do not attack them."
        },
        {
          q: "Where in the chloroplast do the light-dependent reactions occur?",
          options: ["Stroma", "Outer membrane", "Thylakoid membranes", "Cell wall"],
          answer: 2,
          explain: "Chlorophyll and the electron transport chain sit in the thylakoid membranes. The stroma hosts the Calvin cycle."
        },
        {
          q: "In a population in Hardy-Weinberg equilibrium, the frequency of the recessive genotype (q²) is 0.16. What is the frequency of heterozygotes (2pq)?",
          options: ["0.24", "0.36", "0.48", "0.84"],
          answer: 2,
          explain: "q = √0.16 = 0.4, so p = 0.6 and 2pq = 2 × 0.6 × 0.4 = 0.48."
        },
        {
          q: "Which hormone lowers blood glucose concentration?",
          options: ["Glucagon", "Adrenaline", "Insulin", "Cortisol"],
          answer: 2,
          explain: "Insulin from the beta cells of the pancreas makes cells take up glucose and the liver store it as glycogen."
        }
      ]
    },
    {
      id: "chemistry",
      name: "Chemistry",
      questions: [
        {
          q: "What is the pH of a 0.01 M solution of hydrochloric acid (a strong acid)?",
          options: ["1", "2", "7", "12"],
          answer: 1,
          explain: "HCl dissociates completely, so [H⁺] = 0.01 = 10⁻² M and pH = 2."
        },
        {
          q: "How many moles are in 36 g of water? (H = 1, O = 16)",
          options: ["1 mol", "2 mol", "18 mol", "36 mol"],
          answer: 1,
          explain: "The molar mass of H₂O is 18 g/mol, so 36 g ÷ 18 g/mol = 2 mol."
        },
        {
          q: "Across a period from left to right, electronegativity generally:",
          options: ["Decreases", "Increases", "Stays the same", "First falls then rises"],
          answer: 1,
          explain: "Nuclear charge rises while the shielding stays similar, so atoms attract bonding electrons more strongly."
        },
        {
          q: "For N₂(g) + 3H₂(g) ⇌ 2NH₃(g), increasing the pressure at constant temperature shifts the equilibrium:",
          options: ["To the left", "To the right", "It does not shift", "It stops the reaction"],
          answer: 1,
          explain: "The right side has fewer moles of gas (2 against 4), and Le Chatelier's principle says the system moves to reduce pressure."
        },
        {
          q: "What is the oxidation number of manganese in KMnO₄?",
          options: ["+2", "+4", "+6", "+7"],
          answer: 3,
          explain: "K is +1 and four O atoms are −8 in total, so Mn must be +7 to make the compound neutral."
        },
        {
          q: "What is the general formula of the alkanes?",
          options: ["CₙH₂ₙ", "CₙH₂ₙ₊₂", "CₙH₂ₙ₋₂", "CₙHₙ"],
          answer: 1,
          explain: "Alkanes are saturated hydrocarbons, for example CH₄, C₂H₆ and C₃H₈."
        },
        {
          q: "What type of bonding holds sodium chloride together?",
          options: ["Covalent", "Ionic", "Metallic", "Hydrogen bonding"],
          answer: 1,
          explain: "Sodium gives an electron to chlorine, and the Na⁺ and Cl⁻ ions are held by electrostatic attraction."
        },
        {
          q: "What volume does one mole of an ideal gas occupy at STP (0 °C, 1 atm)?",
          options: ["11.2 L", "22.4 L", "24.0 L", "44.8 L"],
          answer: 1,
          explain: "At standard temperature and pressure one mole of an ideal gas occupies 22.4 litres."
        }
      ]
    },
    {
      id: "physics",
      name: "Physics",
      questions: [
        {
          q: "A 2 kg mass accelerates at 3 m/s². What is the net force on it?",
          options: ["1.5 N", "5 N", "6 N", "9 N"],
          answer: 2,
          explain: "Newton's second law: F = ma = 2 × 3 = 6 N."
        },
        {
          q: "Ignoring air resistance, at what launch angle does a projectile have the greatest horizontal range on level ground?",
          options: ["30°", "45°", "60°", "90°"],
          answer: 1,
          explain: "Range is proportional to sin 2θ, which is largest when 2θ = 90°, so θ = 45°."
        },
        {
          q: "A 12 V battery is connected across a 4 Ω resistor. What current flows?",
          options: ["0.33 A", "3 A", "8 A", "48 A"],
          answer: 1,
          explain: "Ohm's law: I = V ÷ R = 12 ÷ 4 = 3 A."
        },
        {
          q: "What is the kinetic energy of a 2 kg object moving at 3 m/s?",
          options: ["3 J", "6 J", "9 J", "18 J"],
          answer: 2,
          explain: "KE = ½mv² = ½ × 2 × 3² = 9 J."
        },
        {
          q: "A wave has frequency 50 Hz and wavelength 2 m. What is its speed?",
          options: ["25 m/s", "52 m/s", "100 m/s", "200 m/s"],
          answer: 2,
          explain: "v = fλ = 50 × 2 = 100 m/s."
        },
        {
          q: "An object is placed beyond 2F of a converging lens. The image formed is:",
          options: ["Real, inverted, diminished", "Real, upright, magnified", "Virtual, upright, magnified", "Virtual, inverted, diminished"],
          answer: 0,
          explain: "Beyond 2F the image forms between F and 2F on the other side. It is real, inverted and smaller than the object."
        },
        {
          q: "In the photoelectric effect, with light above the threshold frequency, increasing the light intensity (same frequency) will:",
          options: ["Increase the maximum kinetic energy of electrons", "Increase the number of electrons emitted per second", "Decrease the threshold frequency", "Stop the emission"],
          answer: 1,
          explain: "Intensity sets the number of photons, so more electrons are emitted. Maximum kinetic energy depends on frequency, not intensity."
        },
        {
          q: "The length of a simple pendulum is doubled. By what factor does its period change?",
          options: ["×2", "×√2", "×½", "It does not change"],
          answer: 1,
          explain: "T = 2π√(L/g), so doubling L multiplies T by √2."
        }
      ]
    },
    {
      id: "math",
      name: "Mathematics",
      questions: [
        {
          q: "What is the derivative of x³ with respect to x?",
          options: ["x²", "3x²", "3x³", "x³/3"],
          answer: 1,
          explain: "The power rule: d/dx xⁿ = nxⁿ⁻¹, so d/dx x³ = 3x²."
        },
        {
          q: "Evaluate the definite integral of 2x dx from x = 0 to x = 3.",
          options: ["3", "6", "9", "18"],
          answer: 2,
          explain: "The antiderivative is x². Then 3² − 0² = 9."
        },
        {
          q: "Solve x² − 5x + 6 = 0.",
          options: ["x = 1 or 6", "x = 2 or 3", "x = −2 or −3", "x = −1 or −6"],
          answer: 1,
          explain: "Factorise: (x − 2)(x − 3) = 0, so x = 2 or x = 3."
        },
        {
          q: "What is the sum of the first 10 terms of the arithmetic sequence with first term 2 and common difference 3?",
          options: ["95", "155", "185", "310"],
          answer: 1,
          explain: "Sₙ = n/2 [2a + (n − 1)d] = 5 × (4 + 27) = 155."
        },
        {
          q: "What is the value of log₂ 32?",
          options: ["4", "5", "6", "16"],
          answer: 1,
          explain: "2⁵ = 32, so log₂ 32 = 5."
        },
        {
          q: "What is sin 30°?",
          options: ["√3/2", "1/2", "√2/2", "1"],
          answer: 1,
          explain: "From the 30°-60°-90° triangle, sin 30° = 1/2."
        },
        {
          q: "In how many different orders can 4 distinct books be arranged on a shelf?",
          options: ["12", "16", "24", "64"],
          answer: 2,
          explain: "4! = 4 × 3 × 2 × 1 = 24."
        },
        {
          q: "What is the slope of the line through (1, 2) and (3, 8)?",
          options: ["2", "3", "4", "6"],
          answer: 1,
          explain: "Slope = (8 − 2) ÷ (3 − 1) = 6 ÷ 2 = 3."
        }
      ]
    }
  ]
};

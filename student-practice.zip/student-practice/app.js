(function () {
  'use strict';

  var BANK = window.QUESTION_BANK || { subjects: [] };
  var KEY = 'practice-desk-v1';
  var app = document.getElementById('app');
  var settings = { count: 10, shuffle: true };
  var S = null; // current round

  /* ---------- helpers ---------- */
  function load() { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } }
  function save(d) { try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (e) { /* storage blocked */ } }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function shuffle(a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function range(n) { var r = []; for (var i = 0; i < n; i++) r.push(i); return r; }
  function allQuestions() {
    var out = [];
    BANK.subjects.forEach(function (s) { out = out.concat(s.questions); });
    return out;
  }

  /* ---------- screens ---------- */
  function renderHome() {
    S = null;
    var stats = load();
    var total = allQuestions().length;
    var cards = BANK.subjects.map(function (s) {
      var st = stats[s.id];
      var best = st ? 'Best ' + st.best + '% · ' + st.attempts + (st.attempts === 1 ? ' round' : ' rounds') : 'Not tried yet';
      return '<button class="card" type="button" data-act="start" data-id="' + esc(s.id) + '">' +
        '<div><h2>' + esc(s.name) + '</h2><div class="meta">' + s.questions.length + ' questions</div></div>' +
        '<div class="best">' + esc(best) + '</div></button>';
    }).join('');
    var mixed = '<button class="card" type="button" data-act="start" data-id="mixed">' +
      '<div><h2>Mixed</h2><div class="meta">' + total + ' questions from every subject</div></div>' +
      '<div class="best">' + (stats.mixed ? 'Best ' + stats.mixed.best + '%' : 'Not tried yet') + '</div></button>';

    function seg(val, label) {
      return '<button type="button" data-act="count" data-v="' + val + '" aria-pressed="' + (String(settings.count) === String(val)) + '">' + label + '</button>';
    }
    app.innerHTML =
      '<section class="screen">' +
      '<div class="tag">Question practice</div>' +
      '<h1>Pick a subject and start.</h1>' +
      '<p class="sub">Answer one question at a time. You see the right answer and a short explanation straight away, and a list of what to review at the end.</p>' +
      '<div class="controls">' +
        '<span class="lbl">Questions per round</span>' +
        '<span class="seg" role="group" aria-label="Questions per round">' + seg(5, '5') + seg(10, '10') + seg('all', 'All') + '</span>' +
        '<label class="chk lbl"><input type="checkbox" id="shuf"' + (settings.shuffle ? ' checked' : '') + '> Shuffle order</label>' +
      '</div>' +
      '<div class="subjects">' + cards + mixed + '</div>' +
      '</section>';
  }

  function startRound(id, retryPool) {
    var pool, name;
    if (retryPool) { pool = retryPool; name = 'Review round'; }
    else if (id === 'mixed') { pool = allQuestions(); name = 'Mixed'; }
    else {
      var sub = BANK.subjects.filter(function (s) { return s.id === id; })[0];
      if (!sub) { renderHome(); return; }
      pool = sub.questions; name = sub.name;
    }
    var qs = settings.shuffle ? shuffle(pool) : pool.slice();
    if (!retryPool && settings.count !== 'all') qs = qs.slice(0, Number(settings.count));
    S = {
      id: id, name: name, retry: !!retryPool, i: 0, score: 0, missed: [], answered: false,
      qs: qs.map(function (q) {
        return { src: q, order: settings.shuffle ? shuffle(range(q.options.length)) : range(q.options.length) };
      })
    };
    renderQuestion();
  }

  function renderQuestion() {
    var item = S.qs[S.i], q = item.src;
    var pct = Math.round((S.i / S.qs.length) * 100);
    var opts = item.order.map(function (orig, pos) {
      return '<li><button class="opt" type="button" data-act="pick" data-o="' + orig + '">' +
        '<span class="k">' + (pos + 1) + '</span><span class="t">' + esc(q.options[orig]) + '</span></button></li>';
    }).join('');
    app.innerHTML =
      '<section class="screen">' +
      '<div class="quiz-head"><span>' + esc(S.name) + '</span><span>Question ' + (S.i + 1) + ' of ' + S.qs.length + '</span></div>' +
      '<div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + pct + '"><i style="width:' + pct + '%"></i></div>' +
      '<h2 class="q">' + esc(q.q) + '</h2>' +
      '<ul class="opts">' + opts + '</ul>' +
      '<div id="fb"></div>' +
      '</section>';
    S.answered = false;
  }

  function pick(orig) {
    if (!S || S.answered) return;
    S.answered = true;
    var item = S.qs[S.i], q = item.src;
    var correct = orig === q.answer;
    if (correct) S.score++; else S.missed.push(q);
    var btns = app.querySelectorAll('.opt');
    btns.forEach(function (b) {
      var o = Number(b.getAttribute('data-o'));
      b.disabled = true;
      if (o === q.answer) b.classList.add('right');
      if (o === orig) { b.classList.add('picked'); if (!correct) b.classList.add('wrong'); }
    });
    var last = S.i === S.qs.length - 1;
    document.getElementById('fb').innerHTML =
      '<div class="explain"><p class="verdict ' + (correct ? 'good' : 'bad') + '">' + (correct ? 'Correct' : 'Not quite') + '</p>' +
      (correct ? '' : '<div>Right answer: <b>' + esc(q.options[q.answer]) + '</b></div>') +
      (q.explain ? '<div>' + esc(q.explain) + '</div>' : '') + '</div>' +
      '<div class="actions"><button class="btn primary" type="button" data-act="next">' + (last ? 'See results' : 'Next question') + ' →</button></div>';
    var nb = document.querySelector('[data-act="next"]');
    if (nb) nb.focus();
  }

  function next() {
    if (!S || !S.answered) return;
    if (S.i < S.qs.length - 1) { S.i++; renderQuestion(); } else { renderResults(); }
  }

  function renderResults() {
    var total = S.qs.length, pct = Math.round((S.score / total) * 100);
    if (!S.retry) {
      var stats = load();
      var st = stats[S.id] || { best: 0, attempts: 0 };
      st.best = Math.max(st.best, pct); st.attempts++; st.last = pct;
      stats[S.id] = st; save(stats);
    }
    var msg = pct === 100 ? 'Perfect round.' : pct >= 80 ? 'Strong. Check the few you missed.' : pct >= 50 ? 'Getting there. Review the misses below, then go again.' : 'Needs more work. Read each explanation, then retry.';
    var review = S.missed.length
      ? '<h3 class="sec">To review (' + S.missed.length + ')</h3><ul class="review">' + S.missed.map(function (q) {
          return '<li><p class="rq">' + esc(q.q) + '</p><p class="ra">Answer: <b>' + esc(q.options[q.answer]) + '</b>' + (q.explain ? '. ' + esc(q.explain) : '') + '</p></li>';
        }).join('') + '</ul>'
      : '<div class="empty" style="margin-top:24px">You got every question right.</div>';
    app.innerHTML =
      '<section class="screen">' +
      '<div class="tag">' + esc(S.name) + ' · results</div>' +
      '<div class="score">' + S.score + '<small> / ' + total + '</small></div>' +
      '<p class="msg">' + pct + '%. ' + esc(msg) + '</p>' +
      '<div class="actions" style="margin-top:0">' +
        (S.missed.length ? '<button class="btn primary" type="button" data-act="retry">Retry missed questions</button>' : '') +
        '<button class="btn' + (S.missed.length ? '' : ' primary') + '" type="button" data-act="again">Another round</button>' +
        '<button class="btn" type="button" data-act="home">All subjects</button>' +
      '</div>' + review + '</section>';
    window.scrollTo(0, 0);
  }

  /* ---------- events ---------- */
  app.addEventListener('click', function (e) {
    var t = e.target.closest('[data-act]');
    if (!t) return;
    var act = t.getAttribute('data-act');
    if (act === 'start') startRound(t.getAttribute('data-id'));
    else if (act === 'pick') pick(Number(t.getAttribute('data-o')));
    else if (act === 'next') next();
    else if (act === 'home') renderHome();
    else if (act === 'again') startRound(S.id);
    else if (act === 'retry') startRound(S.id, S.missed.slice());
    else if (act === 'count') {
      var v = t.getAttribute('data-v');
      settings.count = v === 'all' ? 'all' : Number(v);
      renderHome();
    }
  });
  app.addEventListener('change', function (e) {
    if (e.target.id === 'shuf') settings.shuffle = e.target.checked;
  });
  document.addEventListener('keydown', function (e) {
    if (!S || e.metaKey || e.ctrlKey || e.altKey) return;
    if (!S.answered && /^[1-9]$/.test(e.key)) {
      var item = S.qs[S.i], idx = Number(e.key) - 1;
      if (idx < item.order.length && document.querySelector('.opt')) pick(item.order[idx]);
    } else if (S.answered && (e.key === 'Enter' || e.key === 'ArrowRight') && document.querySelector('[data-act="next"]')) {
      if (document.activeElement && document.activeElement.getAttribute('data-act') === 'next') return;
      e.preventDefault(); next();
    }
  });

  /* theme toggle */
  document.getElementById('themeBtn').addEventListener('click', function () {
    var root = document.documentElement, cur = root.getAttribute('data-theme');
    var dark = cur === 'dark' || (!cur && window.matchMedia('(prefers-color-scheme: dark)').matches);
    root.setAttribute('data-theme', dark ? 'light' : 'dark');
  });

  renderHome();
})();
